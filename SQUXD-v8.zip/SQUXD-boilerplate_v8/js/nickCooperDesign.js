$(document).ready(function () {
    $('div.pageLoadedDiv').fadeIn(1000).removeClass('pageLoadedDiv');
window.onload = function() {
    
		// animation code
		TweenLite.from(".box-nc", 1, {y:"+200px"});
		TweenLite.from(".NCD-diamond-back", 0.8, { ease: Bounce.easeOut, autoAlpha:0, y:-200, delay:2});
		TweenLite.set(".NCD-diamond-back", {visibility:"visible"});
		TweenLite.from(".box-nc", 0.75, {autoAlpha:0, delay:0.35}, "-=2");
		TweenLite.set(".box-nc", {visibility:"visible"});

		var tl = new TimelineMax({paused:true});

		tl.to("#paperLogo", 0.25, {autoAlpha:0, progress:1})
		  .staggerTo("#lineLogo", 0, {autoAlpha:1, progress:1}, "-=0.25");

		tl.timeScale(1);

		$(".box-nc, .NCD-diamond-back").hover(function(){
		  tl.play();
		},function(){
		  tl.reverse();
		});

		tl.timeScale(1);

		$(".column p a").hover(function(){
		  tl.play();
		},function(){
		  tl.reverse();
		})

		tl.to(".column h5 span", 0, {autoAlpha:0, color:"#FFF", progress:0})
		  .staggerTo(".column h5 span", 0, {autoAlpha:0.5, color:"#000", progress:1}, "-=0.001");

		tl.timeScale(1);

TweenLite.render()};
});