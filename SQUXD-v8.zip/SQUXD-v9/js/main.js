$(document).ready(function () {
    $('div.pageLoadedDiv').fadeIn(1000).removeClass('pageLoadedDiv');
window.onload = function() {
    	
    	// Diamond Drops
		TweenLite.from("#diamond", 0.5, {smoothOrigin:true, ease:Power1.easeOut, fill:"#00bbd3", autoAlpha:0, y:"-300px", progress:0, delay:0.5});

		// animation code
		TweenLite.set(".box-uxd, .blue-uxd, #xa-flip, #a", {visibility:"visible"});

		// (var1) "X-A" TEXT SCRAMBLER
		var textBtnTl = new TimelineMax({repeat:-1, delay:5});

		textBtnTl.to("#x-a", 10, {scrambleText:{text:"X", chars:"XAXX", revealDelay:6, tweenLength:true, speed:0.01, ease:Linear.easeNone}});


		// (var2) FLIP "X" TO "A" + Diamond UP
		var tl = new TimelineMax({paused:true});

		tl.to("#x", 0.125, {scaleX:0, transformOrigin:"58% 42%", ease: Linear.easeNone, delay: 0.03, smoothOrigin:true}, 0)
		  .to("#diamond", 0.425, {ease:Elastic.easeOut.config(0.55, 0.85), yPercent:-83.5, fill:"#00bbd3", smoothOrigin:true}, "-=0.1")
		  .from("#a", 0.125, {scaleX:0, transformOrigin:"58% 42%", ease:Linear.easeNone, delay: 0.03, smoothOrigin:true}, "-=0.25")

		tl.timeScale(1.2);

		$("#xa-flip, .button").hover(function(){
		  tl.play();
		},function(){
		  tl.reverse();
		})


		//---(var3)---DIAMOND FLOAT/HOVER-------- 
		var loop=1, diamondTl = new TimelineMax({repeat:-1});

		diamondTl
		  .to("#diamond",0.4, {y:"-=2px", smoothOrigin:true, ease:Power1.easeOut, opacity:0.75}, "-=0.35")
		  .to("#diamond",0.35, {y:0, smoothOrigin:true, ease:Power1.easeOut, opacity:1}, "+=0.1");

		diamondTl.paused(true)
		  .add(function(){loop=0});
		$("#xa-flip, .button").hover(function(){
		  diamondTl.play();
		},function(){
		  diamondTl.pause();
		  TweenLite.from("#diamond", 1, {fill:"#00bbd3", progress:0})
		  TweenLite.to(diamondTl, 0.25, {progress:0})
		})

		// HOVER "S"Q"UXD" CHANGE COLOR/BUTTON TEXT
		$("#s, #q, .blue-uxd:not(#diamond, #xa-flip)").hover(over, out);
		function over(){
		  TweenMax.to(this, 0.25, {fill:"#00bbd3"})
		}
		function out(){
		  TweenMax.to(this, 2, {fill:"#000000"})
		}

		var joinButton = $(".button #joinButton"),
		    joinButtonActive = $("#joinButtonActive"),
		    sButton = $(".button #simpleButton"),
		    qButton = $(".button #qualityButton"),
		    uxdButton = $(".button #uxdButton"),
		    button = $(".button"),
		    uxd = $("#u, #x, #d");

		$(function(){
		    $("#s").hover(function(){
		        joinButton.hide(),
		        sButton.show();
		    }, function(){
		        sButton.hide(),
		        joinButton.show();
		    }),
		    $("#q").hover(function(){
		        joinButton.hide();
		        qButton.show();
		    }, function(){
		        qButton.hide();
		        joinButton.show();
		    }),
		    $(".box-uxd").hover(function(){
		        joinButton.hide();
		        uxdButton.show();
		    }, function(){
		        uxdButton.hide();
		        joinButton.show();
		    }),
		    $(".blue-uxd:not(#diamond, #a)").hover(function(){
		        TweenMax.to(uxd, 0.25, {fill:"#00bbd3", progress:0});
		        joinButton.hide();
		        uxdButton.show();
		    }, function(){
		        TweenMax.to(uxd, 2, {fill:"#000000", progress:0});
		        uxdButton.hide();
		        joinButton.show();
		    }),
		    $("#xa-flip").hover(function(){
		        TweenMax.to(uxd, 0.25, {fill:"#000000", progress:0});
		        button.hide();
		        uxdButton.hide();
		        joinButton.hide();
		        joinButtonActive.show();
		    }, function(){
		        TweenMax.to(uxd, 0.25, {fill:"#000000", progress:0});
		        joinButtonActive.hide();
		        button.show();
		        joinButton.show();
		    });
		});

TweenLite.render()};
});