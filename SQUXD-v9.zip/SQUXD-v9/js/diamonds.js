$(document).ready(function () {
 
		// Innovative Experiences - DIAMOND 1
		TweenLite.set(".svg-icon-1, #morphWindmill", {visibility:"visible"});

		MorphSVGPlugin.convertToPath("circle");

		var tl = new TimelineMax({paused:true})
			.to("#diamondTop-1", 0.75, {stroke:"#4caf50", morphSVG:{ shape:".windmill", shapeIndex:11, scale: 1}})
		  	.to("#d-IE", 0.75, {css:{color:"#4caf50"}}, "-=0.75");

		tl.timeScale(2);

		$(".svg-icon-1").hover(function(){
		  tl.play();
		},function(){
		  tl.reverse();
		})
		$(".svg-icon-1").click(function(){
		  tl.reverse();
		})

		// Elegant Interactions - DIAMOND 2
		TweenLite.set(".svg-icon-2, #morphFlamingo", {visibility:"visible"});

		MorphSVGPlugin.convertToPath("circle");

		var tl = new TimelineMax({paused:true})
			.to("#diamondTop-2", 0.75, {stroke:"#EC407A", morphSVG:{ shape:".flamingo", shapeIndex:5, scale: 1}})
			.to("#flamingoEye", 0.25, {autoAlpha: 1}, "-=0.1")
			.to("#d-EI", 0.75, {css:{color:"#EC407A"}}, "-=0.75");

		tl.timeScale(2);

		$(".svg-icon-2").hover(function(){
		  tl.play();
		},function(){
		  tl.reverse();
		})
		$(".svg-icon-2").click(function(){
		  tl.reverse();
		})

		// Insightful Perspectives - DIAMOND 3
		TweenLite.set(".svg-icon-3, #morphMagicLightbulb", {visibility:"visible"});

		MorphSVGPlugin.convertToPath("circle");


		var tl = new TimelineMax({paused:true})
			.to("#diamondTop-3", 0.75, {stroke:"#ff9800", morphSVG:{ shape:".magician", shapeIndex:11, scale: 1}})
			.to(".bulbFace, #topButton", 0.25, {autoAlpha: 1}, "-=0.275")
			.to("#d-IP", 0.75, {css:{color:"#ff9800"}}, "-=0.75");

		tl.timeScale(2);


		$(".svg-icon-3").hover(function(){
		  tl.play();
		},function(){
		  tl.reverse();
		})
		$(".svg-icon-3").click(function(){
		  tl.play();
		},function(){
		  tl.reverse();
		})
		$(".svg-icon-3").click(function(){
		  tl.reverse();
		})

TweenLite.render();
});